package com.pa.comparator;


public class ComparationHelper {

	public static ComparationVO getBiggest() {
		return null;
	}
}
