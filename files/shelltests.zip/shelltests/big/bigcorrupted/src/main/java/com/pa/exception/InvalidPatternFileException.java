package com.pa.exception;

@SuppressWarnings("serial")
public class InvalidPatternFileException extends Exception{
	public InvalidPatternFileException(String message) { 
		super(message); 
	}
}
