package com.pa.util;

public enum EnumQualisClassification {
	A1,
	A2,
	B1,
	B2,
	B3,
	B4,
	B5,
	C,
	NONE
}
