package com.pa.database;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	
	QualisDatabaseTest.class,
	QualisDatabaseTest.class,
	PublicationDatabaseTest.class,
	PublicationTypeDatabaseTest.class,
	CurriculoDatabaseTest.class,
	GroupDatabaseTest.class
	
	})
public class DatabaseTest {

}
