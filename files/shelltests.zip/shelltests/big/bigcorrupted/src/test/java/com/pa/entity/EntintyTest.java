package com.pa.entity;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;


@RunWith(Suite.class)
@Suite.SuiteClasses({
	
	QualisTest.class,
	QualisDataTest.class,
	PublicationTest.class,
	PublicationTypeTest.class,
	CurriculoTest.class,
	GroupTest.class
	
	})
public class EntintyTest {}
