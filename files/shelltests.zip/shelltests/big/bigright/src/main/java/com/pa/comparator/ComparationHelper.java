package com.pa.comparator;


public class ComparationHelper {

    private int contador = 2;

	public static ComparationVO getSmallest() {
		return null;
	}
}
