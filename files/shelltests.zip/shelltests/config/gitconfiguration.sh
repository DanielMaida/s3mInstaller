cp .gitconfig $HOME
cp .gitattributes $HOME
cp jFSTMerge.jar $HOME
